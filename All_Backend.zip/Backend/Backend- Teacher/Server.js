const express = require('express')
const cors = require('cors')
const config = require('./config')
const app = express()

const teacherRoute = require('./routes/Teacher')

app.use(cors())
app.use(express.json())

app.use('/teacher', teacherRoute)

app.listen(4000, () => {
    console.log(`Server running at http://localhost:4000`)
})