const express = require('express')
const router = express.Router()
const config = require('../config')
const db = require('../database')
const utils = require('../utils')

// Register as staff
router.post('/register', async (req, res) => {
    const {  first_name, last_name,email, password } = req.body;

    const statement = `INSERT INTO teacher( first_name, last_name,email, password) VALUES (?,?,?,?)`
  
    db.pool.execute(
        statement,
        [ first_name, last_name,email, utils.encryptPassword(password)],
        (error, result) => {

            console.log(`${first_name}`)

            res.send(utils.createResult(error, result))
        }
    )
 })

//Login for staff
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

  const statement = `
  SELECT first_name, last_name FROM teacher
  WHERE email = ? AND password = ?
  `
//   const hashedPassword = utils.encryptPassword(password)
//   console.log('Encrypted password:', hashedPassword)

  db.pool.query(statement, [email, password], (error, teachers) => {
    if (error) {
        res.send(utils.createError(error))
    } else {
        console.log('User result:', teachers)

        if (teachers.length === 0) {
            res.send(utils.createError('User does not exist'))
        } else {
            const { first_name, last_name } = user[0]
            const payload = { first_name, last_name}

            try{
                const token = jwt.sign(payload, config.secret)
                console.log('Generated token:', token)

                res.send(
                    utils.createSuccess({
                        token,
                        first_name,
                        last_name,
                    })
                )
            } catch (ex){
                res.send(utils.createError(ex))
            }
        }

    }
  })
})


module.exports = router