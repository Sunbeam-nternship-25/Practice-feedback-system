const express = require('express')
const router = express.Router()
const config = require('../config')
const db = require('../database')
const utils = require('../utils')




// View Feedback Given by the Student

router.get('/feedback/:studentId', (req, res) => {
   
})