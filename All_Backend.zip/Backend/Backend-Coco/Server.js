const express = require('express')
const cors = require('cors')
const app = express()
const config = require('./config')

const adminRoute = require('./routes/coco')

app.use(cors())
app.use(express.json())

app.use('/admin', adminRoute)

app.listen(4003, () => {
    console.log(`Server running at http://localhost:4003`)
})