require('dotenv').config()
const express = require('express')
const cors = require('cors')
const app = express()


const studentRoute = require('./routes/student')

app.use(cors())
app.use(express.json())

app.use('/student', studentRoute)

app.listen(4002, () => {
    console.log(`Server running at http://localhost:4002`)
})