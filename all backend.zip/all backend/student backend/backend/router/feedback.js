const express = require("express");
const db = require("../database");
const utils = require("../utils");
const config = require("../config");



const router = express.Router();

router.post('/insert' , (request,response)=>{
    
})