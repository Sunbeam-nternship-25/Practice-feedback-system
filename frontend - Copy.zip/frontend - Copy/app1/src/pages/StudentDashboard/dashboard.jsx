import React from "react";
import "./dashboard.css"

function StudentDashboard() {
  return (
    <div className="container">
      <div className="login-form-container">
        <h2 style={{ textAlign: "center", color: "#004aad" }}>Feedback Report</h2>

        {/* Report Header */}
        <div className="input-container">
          <label>Feedback Type:</label>
          <input type="text" value="PreCAT_Online_Module_End_Theory" readOnly />
        </div>
        <div className="input-container">
          <label>Course:</label>
          <input type="text" value="PH-35-LAPTOP" readOnly />
        </div>
        <div className="input-container">
          <label>Module:</label>
          <input type="text" value="Basics BigData" readOnly />
        </div>
        <div className="input-container">
          <label>Date:</label>
          <input type="text" value="03-Jul-2025 to 10-Jul-2025" readOnly />
        </div>

        {/* Faculty Feedback Summary */}
        <h3 style={{ marginTop: "15px", color: "#444" }}>Faculty Feedback Summary</h3>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#004aad", color: "white" }}>
              <th>Question</th>
              <th>Excellent</th>
              <th>Good</th>
              <th>Satisfactory</th>
              <th>Unsatisfactory</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Faculty’s communication/Presentation skills?</td>
              <td>7</td><td>3</td><td>0</td><td>1</td>
            </tr>
            <tr>
              <td>Faculty’s responsiveness and interaction?</td>
              <td>8</td><td>2</td><td>0</td><td>1</td>
            </tr>
            <tr>
              <td>Quality of Lecture material & Teaching aids?</td>
              <td>7</td><td>3</td><td>0</td><td>1</td>
            </tr>
            {/* Add remaining rows same way */}
          </tbody>
        </table>

        {/* Button */}
        <div style={{ marginTop: "15px", textAlign: "center" }}>
          <button className="btn-success">Export Report</button>
        </div>
      </div>
    </div>
  );
}

export default  StudentDashboard ;
