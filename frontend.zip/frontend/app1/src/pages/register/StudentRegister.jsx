import { useState,useEffect } from 'react';
import Navbar from '../navbar/navbar.jsx';
import { register } from "../../service/student.js";
import { getCourses,getGroups } from "../../service/student.js";
import { toast } from 'react-toastify';

function StudentRegister() {
  const [form, setForm] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    prn_no: '',
    course_id: '',
    group_id: ''
  });

  const [courses, setCourses] = useState([]);
  const [groups, setGroups] = useState([]);

  useEffect(() => {
    async function fetchData(){
      const courseData = await getCourses();
    if (courseData.status === "success") setCourses(courseData.data);

    const groupData = await getGroups();
    if (groupData.status === "success") setGroups(groupData.data);
  }
  fetchData();
}, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const onRegister = async () => {
    if (!form.first_name || !form.last_name || !form.email || !form.password) {
      toast.warn('Please fill in all required fields');
      return;
    }

    const result = await register(
      form.first_name,
      form.last_name,
      form.email,
      form.password,
      form.prn_no,
      form.course_id,
      form.group_id
    );

    if (result.status === 'success') {
      toast.success('Registration successful');
      setForm({ first_name: '', last_name: '', email: '', password: '', prn_no:'', group_id: '',course_id: ''});
    } else {
      toast.error(result.error || 'Registration failed');
    }
  };

  return (
    <div>
      <Navbar />
      <div className='container'>
        <h2 className='page-header'>Student Registration</h2>
        <div className='login-form-container'>

          {['first_name', 'last_name', 'email', 'password','prn_no'].map((field) => (
            <div className='input-container' key={field}>
              <label>{field.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</label>
              <input
                type={field === 'password' ? 'password' : field === 'email' ? 'email' : 'text'}
                name={field}
                value={form[field]}
                onChange={handleChange}
              />
            </div>
          ))}
        
        <div className='input-container'>
           
           {/* Course */}
          <label>Course</label>
          <select 
          name="group_id" 
          value={form.group_id} 
          onChange={handleChange} 
          className='dropdown'
          >
            <option value="">--Select Course--</option>
            {courses.map(courses => (
              <option key={courses.course_id} value={courses.courses_id}>
                {courses.course_name}
              </option>
            ))}
          </select>
        </div>
        
        {/* Group */}
        <div className='input-container'>
          <label>Group</label>
          <select
           name="group_id" 
           value={form.group_id} 
           onChange={handleChange}
          className='dropdown'
          >
            <option value="">--Select Group--</option>
            {groups.map(group => (
              <option key={group.group_id} value={group.group_id}>
                {group.group_name}
              </option>
            ))}
          </select>
        </div>

          <div className='input-container'>
            <button onClick={onRegister} className='btn btn-success'>Register</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default StudentRegister;
