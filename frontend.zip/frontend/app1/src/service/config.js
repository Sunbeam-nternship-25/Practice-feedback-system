export const config ={
    studentServerBaseURL : 'http://localhost:4000',
    teacherServerBaseURL : 'http://localhost:4003',
    cocoServerBaseURL : 'http://localhost:4002',
    adminServerBaseURL : 'http://localhost:4001',
}