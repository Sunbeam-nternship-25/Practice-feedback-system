const express = require("express");
const db = require("../database");
const utils = require("../utils");

const router = express.Router();



router.get('/allFeedback',(request,response)=>{

    const statement = `select * from feedback`;


    db.pool.execute(statement,(error,result)=>{
        response.send(utils.createResult(error,result))
    })
})

module.exports = router;